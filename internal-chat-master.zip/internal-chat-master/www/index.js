const wsUrl = 'wss://neiwang.1024bugs.com/ws';

var users = [];
var me = new XChatUser();
// 将mentionState提升为全局变量
let mentionState = {
  active: false,
  startPos: 0,
  endPos: 0,
  filterText: ''
};

// 添加右键菜单相关代码
let activeMessageElement = null;

// 添加随机昵称生成相关的数据
const adjectives = [
  '快乐的', '悠闲的', '机智的', '可爱的', '优雅的', 
  '神秘的', '活力的', '温柔的', '睿智的', '开朗的',
  '调皮的', '安静的', '热情的', '认真的', '幽默的',
  '文艺的', '勇敢的', '善良的', '聪明的', '可靠的'
];

const nouns = [
  '小猫', '小狗', '小兔', '小熊', '小鹿',
  '海豚', '企鹅', '松鼠', '小象', '长颈鹿',
  '考拉', '小鸟', '蝴蝶', '小狐狸', '小浣熊',
  '小熊猫', '小仓鼠', '小刺猬', '小羊驼', '小树懒'
];

// 添加随机数生成器
function seededRandom(seed) {
  const x = Math.sin(seed) * 10000;
  return x - Math.floor(x);
}

// 修改生成昵称的函数，添加seed参数
function generateNickname(seed) {
  const rand = seededRandom(seed);
  const adjectiveIndex = Math.floor(rand * adjectives.length);
  const nounIndex = Math.floor(seededRandom(seed + 1) * nouns.length);
  
  return `${adjectives[adjectiveIndex]}${nouns[nounIndex]}`;
}

function setRemote() {
  me.setRemoteSdp(remoteSDP.value);
}
function addLinkItem(user, file) {
  const chatBox = document.querySelector('.chat-wrapper');
  const messageContainer = document.createElement('div');
  messageContainer.className = `flex items-start gap-3 my-4 message-animation ${user.id === me.id ? 'flex-row-reverse' : ''}`;
  
  // 判断文件类型
  const isImage = file.type === 'image' || file.name.match(/\.(jpg|jpeg|png|gif|webp)$/i);
  const isVideo = file.name.match(/\.(mp4|webm|ogg)$/i);
  const isAudio = file.name.match(/\.(mp3|wav|ogg)$/i);
  const isPDF = file.name.match(/\.pdf$/i);
  
  let fileIcon = 'description'; // 默认文件图标
  if (isImage) fileIcon = 'image';
  if (isVideo) fileIcon = 'videocam';
  if (isAudio) fileIcon = 'audiotrack';
  if (isPDF) fileIcon = 'picture_as_pdf';
  
  messageContainer.innerHTML = `
    <img class="w-10 h-10 rounded" src="${user.avatar}" alt="${user.nickname}">
    <div class="max-w-[60%]">
      <div class="text-xs text-white/60 mb-1 ${user.id === me.id ? 'text-right' : ''}">${user.nickname}</div>
      <div class="message-bubble relative px-4 py-2 rounded-lg ${
        user.id === me.id 
          ? 'bg-primary text-black' 
          : 'bg-dark-100'
      }">
        ${isImage ? `
          <div class="mb-2 overflow-hidden rounded-lg">
            <img src="${file.url}" 
                 alt="图片" 
                 class="max-w-full max-h-[300px] object-contain hover:opacity-90 transition-opacity cursor-pointer"
                 onclick="window.open('${file.url}', '_blank')"
            >
          </div>
        ` : `
          <a href="${file.url}" 
             download="${file.name}" 
             class="flex items-center gap-2 hover:underline">
            <span class="material-icons text-lg">${fileIcon}</span>
            <div class="flex-1 min-w-0">
              <div class="truncate">[文件] ${file.name}</div>
              ${file.size ? `
                <div class="text-xs opacity-60">
                  ${formatFileSize(file.size)}
                </div>
              ` : ''}
            </div>
          </a>
        `}
      </div>
    </div>
  `;
  
  chatBox.appendChild(messageContainer);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function formatTime(timestamp) {
  const date = new Date(timestamp);
  return `${date.getHours().toString().padStart(2,'0')}:${date.getMinutes().toString().padStart(2,'0')}`;
}

function formatDate(timestamp) {
  const date = new Date(timestamp);
  return `${date.getMonth() + 1}月${date.getDate()}日`;
}

let lastMessageTime = 0;

function addChatItem(user, message, type = 'message') {
  const chatBox = document.querySelector('.chat-wrapper');
  
  // 系统消息
  if (type === 'system') {
    const div = document.createElement('div');
    div.className = 'flex justify-center my-2 message-animation';
    div.innerHTML = `<span class="bg-white/10 text-white/60 text-xs px-3 py-1 rounded-full">${message}</span>`;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
    return;
  }
  
  // 进度条消息
  if (type === 'progress') {
    const progressId = `progress-${Date.now()}`;
    const div = document.createElement('div');
    div.id = progressId;
    div.className = 'flex items-start gap-3 my-4 message-animation';
    div.innerHTML = `
      <div class="w-full bg-dark-200 rounded-lg p-4">
        <div class="flex items-center text-sm text-white/60 mb-3">
          <span class="material-icons text-primary animate-spin mr-2">sync</span>
          <div class="flex-1">
            <div class="mb-1">${message}</div>
            <div class="text-xs text-white/40" id="${progressId}-speed"></div>
          </div>
        </div>
        <div class="h-1.5 bg-white/10 rounded-full overflow-hidden">
          <div class="progress-bar-inner h-full bg-primary transition-all duration-300" style="width: 0%"></div>
        </div>
      </div>
    `;
    chatBox.appendChild(div);
    chatBox.scrollTop = chatBox.scrollHeight;
    return progressId;
  }
  
  // 检查是否需要显示时间
  const now = Date.now();
  if (now - lastMessageTime > 5 * 60 * 1000) {
    const timeDiv = document.createElement('div');
    timeDiv.className = 'flex justify-center my-4 message-animation';
    timeDiv.innerHTML = `
      <span class="bg-white/10 text-white/60 text-xs px-3 py-1 rounded-full">
        ${formatDate(now)} ${formatTime(now)}
      </span>
    `;
    chatBox.appendChild(timeDiv);
  }
  lastMessageTime = now;
  
  // 处理消息内容
  let msg = message;
  // 处理链接
  if (/(http|https):\/\/[a-zA-Z0-9\.\-\/\?=\:_]+/g.test(msg)) {
    msg = msg.replace(/(http|https):\/\/[a-zA-Z0-9\.\-\/\?=\:_]+/g, url => 
      `<a href="${url}" target="_blank" class="text-primary hover:underline">${url}</a>`
    );
  }
  
  // 处理@提及
  msg = msg.replace(/@\[([^\]]+)\]/g, (match, userId) => {
    const mentionedUser = users.find(u => u.id === userId);
    if (mentionedUser) {
      // 判断是否是自己发送的消息
      if (user.id === me.id) {
        // 自己发送的@消息样式 - 使用深色背景和明亮的文字
        return `<span class="inline-flex items-center gap-1 bg-black/30 text-primary font-medium px-2 py-0.5 rounded-md">
          <span class="material-icons text-sm">alternate_email</span>
          ${mentionedUser.nickname}
        </span>`;
      } else {
        // 收到的@消息样式
        return `<span class="inline-flex items-center gap-1 bg-primary/20 text-primary font-medium px-2 py-0.5 rounded-md">
          <span class="material-icons text-sm">alternate_email</span>
          ${mentionedUser.nickname}
        </span>`;
      }
    }
    return match;
  });
  
  // 处理输入框中的@消息格式
  msg = msg.replace(/@\[([^:]+):([^\]]+)\]/g, (match, userId, nickname) => {
    // 判断是否是自己发送的消息
    if (user.id === me.id) {
      // 自己发送的@消息样式
      return `<span class="inline-flex items-center gap-1 bg-black/30 text-primary font-medium px-2 py-0.5 rounded-md">
        <span class="material-icons text-sm">alternate_email</span>
        ${nickname}
      </span>`;
    } else {
      // 收到的@消息样式
      return `<span class="inline-flex items-center gap-1 bg-primary/20 text-primary font-medium px-2 py-0.5 rounded-md">
        <span class="material-icons text-sm">alternate_email</span>
        ${nickname}
      </span>`;
    }
  });
  
  const messageContainer = document.createElement('div');
  messageContainer.className = `flex items-start gap-3 my-4 message-animation ${user.id === me.id ? 'flex-row-reverse' : ''}`;
  
  // 添加右键菜单事件
  messageContainer.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    showContextMenu(e, messageContainer, message);
  });
  
  messageContainer.innerHTML = `
    <img class="w-10 h-10 rounded" src="${user.avatar}" alt="${user.nickname}">
    <div class="max-w-[60%]">
      <div class="text-xs text-white/60 mb-1 ${user.id === me.id ? 'text-right' : ''}">${user.nickname}</div>
      <div class="message-bubble relative px-4 py-2 rounded-lg ${
        user.id === me.id 
          ? 'bg-primary text-black' 
          : 'bg-dark-100'
      }">
        ${msg}
      </div>
    </div>
  `;
  
  chatBox.appendChild(messageContainer);
  chatBox.scrollTop = chatBox.scrollHeight;
}

function sendMessage(msg) {
  const message = msg ?? messageInput.value;
  if (!message.trim()) return; // 防止发送空消息
  
  addChatItem(me, message); // 传递完整的用户对象me，而不是仅传id
  
  // 发送给所有用户
  users.forEach(u => {
    if (u.isMe) {
      return;
    }
    u.sendMessage(message);
  });
  messageInput.value = '';
}

async function sendFile(file) {
  pendingFile = file;
  
  const otherUsers = users.filter(u => !u.isMe);
  
  if (otherUsers.length === 1) {
    const user = otherUsers[0];
    const progressId = addChatItem(null, `正在发送文件: ${file.name}`, 'progress');
    
    try {
      const startTime = Date.now();
      const fileMetadata = { name: file.name, size: file.size };
      
      const onProgress = (sent, total) => {
        const speed = sent / (Date.now() - startTime) * 1000;
        updateProgress(progressId, sent, total, speed);
      };
      
      await user.sendFile(fileMetadata, file, onProgress);
      addChatItem(me, `[文件] ${file.name} (发送给: ${user.nickname})`);
    } catch (error) {
      console.error('发送文件失败:', error);
      alert('发送文件失败，请重试');
    } finally {
      pendingFile = null;
    }
    return;
  }
  
  // 显示用户选择对话框
  showUserSelectModal();
}
function registCandidate() {
  for (const ca of JSON.parse(candidate.value)) {
    me.addIceCandidate(ca);
  }
}


function connectAllOther() {
  if (users.length <= 1) {
    return;
  }
  const targets = users.filter(u => u.id !== me.id);
  for (const target of targets) {
    target.onicecandidate = (candidate) => {
      // console.log('candidate', candidate);
      signalingServer.send(JSON.stringify({uid: me.id, targetId: target.id, type: '9001', data: { candidate }}));
    }
    target.createConnection().then(() => {
      // console.log('targetAddr', target.connAddressMe);
      signalingServer.send(JSON.stringify({uid: me.id, targetId: target.id, type: '9002', data: { targetAddr: target.connAddressMe }}));
    })
  }
}


function refreshUsers(data) {
  resUsers = data.map(
    u => {
      let uOld = users.find(uOld => uOld.id === u.id)
      if (uOld) {
        return uOld;
      }
      let xchatUser = new XChatUser();
      const userInfo = {
        id: u.id,
        isMe: u.id === me.id,
        nickname: u.nickname || generateNickname(parseInt(u.id)), // 使用用户ID作为种子
        avatar: u.avatar || `https://api.dicebear.com/7.x/bottts/svg?seed=${u.id}`
      };
      xchatUser.setUserInfo(userInfo);
      return xchatUser;
    }
  );

  // 更新 me 的信息
  if (!me.nickname) {
    const meUser = resUsers.find(u => u.isMe);
    if (meUser) {
      me.setUserInfo({
        id: meUser.id,
        isMe: true,
        nickname: meUser.nickname,
        avatar: meUser.avatar
      });
    }
  }

  // 找出删除的用户
  const delUsers = users.filter(u => !resUsers.find(u2 => u2.id === u.id));
  delUsers.forEach(u => {
    u.closeConnection();
  });

  users = resUsers;
  for (const u of users) {
    u.onmessage = (msg) => {
      addChatItem(u, msg);
    }
    u.onReviceFile = (file) => {
      addLinkItem(u, file);
    }
  }
  refreshUsersHTML();

  // 添加用户进入/退出提醒
  const newUsers = resUsers.filter(u => !users.find(oldU => oldU.id === u.id));
  const leftUsers = users.filter(u => !resUsers.find(newU => newU.id === u.id));
  
  newUsers.forEach(u => {
    if (!u.isMe) {
      addChatItem(null, `${u.nickname} 加入天室`, 'system');
    }
  });
  
  leftUsers.forEach(u => {
    addChatItem(null, `${u.nickname} 离开了聊天室`, 'system');
  });
  
  document.getElementById('onlineCount').textContent = users.length;
}

function joinedRoom() {
  connectAllOther();
}

function addCandidate(data) {
  users.find(u => u.id === data.targetId).addIceCandidate(data.candidate);
}
async function joinConnection(data) {
  const user = users.find(u => u.id === data.targetId)
  if (!user) {
    return;
  }
  user.onicecandidate = (candidate) => {
    // console.log('candidate', candidate);
    signalingServer.send(JSON.stringify({uid: me.id, targetId: user.id, type: '9001', data: { candidate }}));
  }
  await user.connectTarget(data.offer.sdp)
  signalingServer.send(JSON.stringify({uid: me.id, targetId: user.id, type: '9003', data: { targetAddr: user.connAddressMe }}));
}

async function joinedConnection(data) {
  const target = users.find(u => u.id === data.targetId)
  if (!target) {
    return;
  }
  await target.setRemoteSdp(data.answer.sdp);
}

function refreshUsersHTML() {
  const userList = document.querySelector('#users');
  const currentUsers = new Set(Array.from(userList.children).map(li => li.dataset.userId));
  const newUsers = new Set(users.map(u => u.id));
  
  // 找出要删除的用户
  const toRemove = Array.from(currentUsers).filter(id => !newUsers.has(id));
  
  // 找出要添加的用户
  const toAdd = Array.from(newUsers).filter(id => !currentUsers.has(id));
  
  // 处理要删除的��户
  toRemove.forEach(userId => {
    const li = userList.querySelector(`[data-user-id="${userId}"]`);
    if (li) {
      li.classList.add('user-leave');
      setTimeout(() => li.remove(), 300); // 动画结束后移除元素
    }
  });
  
  // 添加新用户
  toAdd.forEach(userId => {
    const user = users.find(u => u.id === userId);
    if (user) {
      const li = document.createElement('li');
      li.dataset.userId = user.id;
      li.className = 'flex items-center gap-3 p-2 rounded hover:bg-white/5 transition-colors user-enter';
      li.innerHTML = `
        <img class="w-8 h-8 rounded" src="${user.avatar}" alt="${user.nickname}">
        <div class="flex-1 min-w-0">
          <div class="truncate text-sm">
            ${user.nickname}${user.isMe ? ' (我)' : ''}
          </div>
        </div>
      `;
      userList.appendChild(li);
    }
  });
  
  // 更新在线人数
  document.getElementById('onlineCount').textContent = users.length;
}

function enterTxt(event) {
  if (event.ctrlKey || event.shiftKey) {
    return;
  }
  // 检查是否正在@用户（全局变量mentionState是否激活）
  if (mentionState?.active) {
    // 如果@选择器是激活状态，阻止消息发送
    event.preventDefault();
    return;
  }
  if (event.keyCode === 13) {
    sendMessage();
    event.preventDefault();
  }
}

// 连接信令服务器
const signalingServer = new WebSocket(wsUrl);
signalingServer.onopen = () => {
  console.log('Connected to signaling server');
  // 隐藏加载提示
  document.getElementById('loading').style.display = 'none';
  
  setInterval(() => {
    signalingServer.send(JSON.stringify({type: '9999'}));
  }, 1000 * 10);
}
signalingServer.onmessage = ({ data: responseStr }) => {
  const response = JSON.parse(responseStr);
  const { type, data } = response;


  if (type === '1001') {
    me.id = data.id;
    return;
  }
  if (type === '1002') {
    refreshUsers(data);
    return;
  }
  if (type === '1003') {
    joinedRoom()
    return;
  }
  if (type === '1004') {
    addCandidate(data);
    return;
  }
  if (type === '1005') {
    joinConnection(data);
    return;
  }
  if (type === '1006') {
    joinedConnection(data);
    return;
  }
}

function showUserSelectModal() {
  const modal = document.getElementById('userSelectModal');
  const userList = document.getElementById('userSelectList');
  const fileInfo = document.getElementById('fileInfo');
  
  // 显示文件信息
  if (pendingFile) {
    const size = pendingFile.size > 1024 * 1024 
      ? `${(pendingFile.size / (1024 * 1024)).toFixed(2)} MB`
      : `${(pendingFile.size / 1024).toFixed(2)} KB`;
    
    // 优化文件信息显示布局
    fileInfo.innerHTML = `
      <div class="flex items-start gap-3">
        <span class="material-icons text-lg mt-0.5 flex-shrink-0">description</span>
        <div class="flex-1 min-w-0">
          <div class="text-sm text-white/90 break-all">
            ${pendingFile.name}
          </div>
          <div class="text-xs text-white/40 mt-0.5">
            ${size}
          </div>
        </div>
      </div>
    `;
  }
  
  // 清空并重新生成用户列表
  userList.innerHTML = '';
  const otherUsers = users.filter(u => !u.isMe);
  
  otherUsers.forEach(user => {
      const item = document.createElement('div');
    item.className = 'user-select-item group';
      
      item.innerHTML = `
      <div class="flex items-center p-3 rounded-lg bg-dark-100/50 hover:bg-dark-100 cursor-pointer transition-colors">
        <input type="checkbox" value="${user.id}" class="hidden peer">
        <div class="w-5 h-5 rounded border-2 border-white/20 peer-checked:border-primary peer-checked:bg-primary flex items-center justify-center transition-colors">
          <span class="material-icons text-black text-base opacity-0 peer-checked:opacity-100">check</span>
        </div>
        <img class="w-8 h-8 rounded mx-3" src="${user.avatar}" alt="${user.nickname}">
        <div class="flex-1 min-w-0">
          <div class="truncate text-sm text-white/90">${user.nickname}</div>
        </div>
      </div>
    `;
    
    const itemDiv = item.querySelector('div');
        const checkbox = item.querySelector('input[type="checkbox"]');
        
    itemDiv.addEventListener('click', (e) => {
      if (e.target !== checkbox) {
        checkbox.checked = !checkbox.checked;
        updateSendButton();
      }
      });
      
      userList.appendChild(item);
  });
  
  // 重置发送按钮事件
  const sendButton = document.getElementById('sendFileBtn');
  sendButton.onclick = confirmSendFile;
  
  // 更新发送按钮状态
  updateSendButton();
  modal.style.display = 'block';
}

// 更新发送按钮状态
function updateSendButton() {
  const selectedUsers = document.querySelectorAll('#userSelectList input[type="checkbox"]:checked');
  const sendButton = document.getElementById('sendFileBtn');
  sendButton.disabled = selectedUsers.length === 0;
  sendButton.className = selectedUsers.length === 0 
    ? 'btn-primary opacity-50 cursor-not-allowed' 
    : 'btn-primary';
}

// 更新进度条显示
function updateProgress(progressId, sent, total, speed) {
  const progressElement = document.getElementById(progressId);
  if (!progressElement) return;
  
  const progress = (sent / total) * 100;
  const progressBar = progressElement.querySelector('.progress-bar-inner');
  const speedText = document.getElementById(`${progressId}-speed`);
  const progressContainer = progressElement.querySelector('.w-full');
  
  progressBar.style.width = `${progress}%`;
  
  const speedMB = speed / (1024 * 1024);
  const speedDisplay = speedMB >= 1 
    ? `${speedMB.toFixed(2)} MB/s`
    : `${(speed / 1024).toFixed(2)} KB/s`;
  
  speedText.textContent = `${speedDisplay} · ${Math.round(progress)}%`;
  
  // 如果传输完成，添加完成动画并在一段时间后移除进度条
  if (progress >= 100) {
    // 先添加完成动画
    progressContainer.classList.add('progress-complete');
    
    // 等待完成动画结束后，开始淡出动画
    setTimeout(() => {
      progressElement.classList.add('progress-fade-out');
      
      // 等待淡出动画结束后移除元素
      setTimeout(() => {
        progressElement.remove();
      }, 500); // 与 slideOutUp 动画时长相匹配
    }, 1000); // 等待一秒让用户看到100%
  }
}

function cancelSendFile() {
  const modal = document.getElementById('userSelectModal');
  modal.style.display = 'none';
  pendingFile = null;
  pendingImage = null;
}

async function confirmSendFile() {
  if (!pendingFile) return;
  
  const modal = document.getElementById('userSelectModal');
  const userList = document.getElementById('userSelectList');
  const selectedCheckboxes = userList.querySelectorAll('input[type="checkbox"]:checked');
  const selectedUsers = Array.from(selectedCheckboxes).map(checkbox => 
    users.find(u => u.id === checkbox.value)
  );
  
  if (selectedUsers.length === 0) return;
  
  try {
    modal.style.display = 'none';
    
    // 为每个选中的用户创建一个进度条
    const progressIds = selectedUsers.map(user => 
      addChatItem(null, `正在发送文件给 ${user.nickname}: ${pendingFile.name}`, 'progress')
    );
    
      const fileInfo = { name: pendingFile.name, size: pendingFile.size };
      const startTime = Date.now();
      
    // 依次发送给每个选中的用户
      for (let i = 0; i < selectedUsers.length; i++) {
        const user = selectedUsers[i];
      const progressId = progressIds[i];
        
        const onProgress = (sent, total) => {
        const speed = sent / (Date.now() - startTime) * 1000;
        updateProgress(progressId, sent, total, speed);
        };
        
        await user.sendFile(fileInfo, pendingFile, onProgress);
      addChatItem(me, `[文件] ${fileInfo.name} (发送给: ${user.nickname})`);
      }
    } catch (error) {
      console.error('发送文件失败:', error);
      alert('发送文件失败，请重试');
    } finally {
    pendingFile = null;
  }
}

// 表情相关
const emojis = [
  '😀', '😃', '😄', '😁', '😆', '😅', '😂', '', '😊', '😇', 
  '🙂', '🙃', '😉', '😌', '😍', '🥰', '😘', '😗', '😙', '😚',
  '😋', '😛', '😝', '😜', '🤪', '🤨', '🧐', '🤓', '😎', '🤩',
  '', '😏', '😒', '😞', '', '😟', '😕', '🙁', '☹️', '😣',
  '😖', '😫', '😩', '🥺', '😢', '😭', '😤', '😠', '😡', '🤬',
  '🤯', '😳', '🥵', '🥶', '😱', '😨', '😰', '😥', '😓', '🤗',
  '🤔', '🤭', '🤫', '', '😶', '😐', '😑', '', '', '😯'
];

// 初始化表情选择器
function initEmojiPicker() {
  const picker = document.getElementById('emojiPicker');
  const grid = picker.querySelector('.grid');
  
  emojis.forEach(emoji => {
    const button = document.createElement('button');
    button.className = 'w-8 h-8 text-xl hover:bg-white/10 rounded transition-colors flex items-center justify-center';
    button.textContent = emoji;
    button.onclick = () => insertEmoji(emoji);
    grid.appendChild(button);
  });
}

// 显示/隐藏表情选择器
function toggleEmojiPicker() {
  const picker = document.getElementById('emojiPicker');
  const button = document.querySelector('.emoji-btn');
  const rect = button.getBoundingClientRect();
  
  if (picker.classList.contains('hidden')) {
    picker.style.left = `${rect.left}px`;
    picker.style.top = `${rect.top - picker.offsetHeight - 10}px`;
    picker.classList.remove('hidden');
  } else {
    picker.classList.add('hidden');
  }
}

// 插入表情到输入框
function insertEmoji(emoji) {
  const input = document.getElementById('messageInput');
  const start = input.selectionStart;
  const end = input.selectionEnd;
  const text = input.value;
  
  input.value = text.substring(0, start) + emoji + text.substring(end);
  input.selectionStart = input.selectionEnd = start + emoji.length;
  input.focus();
  
  // 选择表情后自动关闭选择器
  document.getElementById('emojiPicker').classList.add('hidden');
}

// 处理图片选择
function handleImageSelect(file) {
  if (!file.type.startsWith('image/')) {
    alert('请选择图片文件');
    return;
  }
  
  const reader = new FileReader();
  reader.onload = async (e) => {
    pendingImage = {
      file,
      dataUrl: e.target.result
    };
    
    const modal = document.getElementById('userSelectModal');
    const userList = document.getElementById('userSelectList');
    const fileInfo = document.getElementById('fileInfo');
    
    // 显示图片信息
    const size = file.size > 1024 * 1024 
      ? `${(file.size / (1024 * 1024)).toFixed(2)} MB`
      : `${(file.size / 1024).toFixed(2)} KB`;
    
    // 优化图片信息显示布局
    fileInfo.innerHTML = `
      <div class="flex items-start gap-3">
        <span class="material-icons text-lg mt-0.5 flex-shrink-0">image</span>
        <div class="flex-1 min-w-0">
          <div class="text-sm text-white/90 break-all">
            ${file.name}
          </div>
          <div class="text-xs text-white/40 mt-0.5">
            ${size}
          </div>
        </div>
      </div>
    `;
    
    // 清空并重新生成用户列表
    userList.innerHTML = '';
    const otherUsers = users.filter(u => !u.isMe);
    
    otherUsers.forEach(user => {
      const item = document.createElement('div');
      item.className = 'user-select-item group';
      
      item.innerHTML = `
        <div class="flex items-center p-3 rounded-lg bg-dark-100/50 hover:bg-dark-100 cursor-pointer transition-colors">
          <input type="checkbox" value="${user.id}" class="hidden peer">
          <div class="w-5 h-5 rounded border-2 border-white/20 peer-checked:border-primary peer-checked:bg-primary flex items-center justify-center transition-colors">
            <span class="material-icons text-black text-base opacity-0 peer-checked:opacity-100">check</span>
          </div>
          <img class="w-8 h-8 rounded mx-3" src="${user.avatar}" alt="${user.nickname}">
          <div class="flex-1 min-w-0">
            <div class="truncate text-sm text-white/90">${user.nickname}</div>
          </div>
        </div>
      `;
      
      const itemDiv = item.querySelector('div');
      const checkbox = item.querySelector('input[type="checkbox"]');
      
      itemDiv.addEventListener('click', (e) => {
        if (e.target !== checkbox) {
          checkbox.checked = !checkbox.checked;
          updateSendButton();
        }
      });
      
      userList.appendChild(item);
    });
    
    // 重置发送按钮事件
    const sendButton = document.getElementById('sendFileBtn');
    const originalOnClick = sendButton.onclick;
    sendButton.onclick = async () => {
      const selectedCheckboxes = userList.querySelectorAll('input[type="checkbox"]:checked');
      const selectedUsers = Array.from(selectedCheckboxes).map(checkbox => 
        users.find(u => u.id === checkbox.value)
      );
      
      if (selectedUsers.length === 0) return;
      
      try {
  modal.style.display = 'none';
        
        // 添加自己的消息
        const messageContent = `
          <div class="image-message">
            <img src="${pendingImage.dataUrl}" class="max-w-full max-h-[300px] rounded-lg object-contain" alt="图片">
          </div>
        `;
        addChatItem(me, messageContent);
        
        // 为每个选中的用户创建一个进度条
        const progressIds = selectedUsers.map(user => 
          addChatItem(null, `正在发送图片给 ${user.nickname}: ${file.name}`, 'progress')
        );
        
        // 依次发送给每个选中的用户
        for (let i = 0; i < selectedUsers.length; i++) {
          const user = selectedUsers[i];
          const progressId = progressIds[i];
          const startTime = Date.now();
          
          const onProgress = (sent, total) => {
            const speed = sent / (Date.now() - startTime) * 1000;
            updateProgress(progressId, sent, total, speed);
          };
          
          await user.sendFile(
            { name: pendingImage.file.name, size: pendingImage.file.size, type: 'image' },
            pendingImage.file,
            onProgress
          );
        }
      } catch (error) {
        console.error('发送图片失败:', error);
        alert('发送图片失败，请重试');
      } finally {
        pendingImage = null;
        sendButton.onclick = originalOnClick;
      }
    };

    // 更新发送按钮状态
    updateSendButton();
    modal.style.display = 'block';
  };
  reader.readAsDataURL(file);
}

// 删除不需要的函数
function closeImagePreview() {
  pendingImage = null;
}

// 添加文件大小格式化函数
function formatFileSize(bytes) {
  if (bytes === 0) return '0 B';
  const k = 1024;
  const sizes = ['B', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return `${(bytes / Math.pow(k, i)).toFixed(1)} ${sizes[i]}`;
}

// 显示右键菜单
function showContextMenu(event, messageElement, messageText) {
  const contextMenu = document.getElementById('contextMenu');
  const copyButton = contextMenu.children[0];
  const deleteButton = contextMenu.children[1];
  
  // 保存当前激活的消息元素
  activeMessageElement = messageElement;
  
  // 设置菜单位置
  contextMenu.style.left = `${event.pageX}px`;
  contextMenu.style.top = `${event.pageY}px`;
  
  // 显示菜单
  contextMenu.classList.remove('hidden');
  
  // 复制消息
  copyButton.onclick = () => {
    // 创建一个临时的文本区域来复制文本
    const textarea = document.createElement('textarea');
    textarea.value = messageText;
    document.body.appendChild(textarea);
    textarea.select();
    document.execCommand('copy');
    document.body.removeChild(textarea);
    
    // 显示复制成功提示
    addChatItem(null, '消息已复制到剪贴板', 'system');
    
    // 隐藏菜单
    hideContextMenu();
  };
  
  // 删除消息
  deleteButton.onclick = () => {
    messageElement.classList.add('opacity-0', 'transition-opacity', 'duration-300');
    setTimeout(() => {
      messageElement.remove();
    }, 300);
    hideContextMenu();
  };
}

// 隐藏右键菜单
function hideContextMenu() {
  const contextMenu = document.getElementById('contextMenu');
  contextMenu.classList.add('hidden');
  activeMessageElement = null;
}

// 在 DOMContentLoaded 中添加事件监听
document.addEventListener('DOMContentLoaded', () => {
  // 获取消息输入框元素
  const messageInput = document.getElementById('messageInput');
  
  // 监听页面可见性变化
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'visible') {
      messageInput.focus();
    }
  });
  
  // 监听全局按键事件
  document.addEventListener('keydown', (e) => {
    // 排除一些特殊按键和组合键
    if (e.ctrlKey || e.altKey || e.metaKey) return;
    // 排除功能键（F1-F12等）
    if (e.key.startsWith('F')) return;
    // 排除已经在输入框中的情况
    if (document.activeElement === messageInput) return;
    // 排除其他输入框和可编辑元素
    if (['INPUT', 'TEXTAREA'].includes(document.activeElement.tagName)) return;
    if (document.activeElement.isContentEditable) return;
    
    // 自动���焦输入框
    messageInput.focus();
  });

  // 拖动文件相关
let droptarget = document.body;
    
  function handleEvent(event) {
  event.preventDefault();
  if (event.type === 'drop') {
    droptarget.classList.remove('dragover');
    if (event.dataTransfer.files.length > 0) {
        handleFileSelect(event.dataTransfer.files[0]);
    }
  } else if (event.type === 'dragleave') {
    droptarget.classList.remove('dragover');
  } else {
    droptarget.classList.add('dragover');
  }
}

droptarget.addEventListener("dragenter", handleEvent);
droptarget.addEventListener("dragover", handleEvent);
droptarget.addEventListener("drop", handleEvent);
droptarget.addEventListener("dragleave", handleEvent);

  // 文件按钮点击事件
  document.querySelector('.file-btn').addEventListener('click', () => {
  const input = document.createElement('input');
  input.type = 'file';
    input.onchange = (e) => {
    if (e.target.files.length > 0) {
        handleFileSelect(e.target.files[0]);
    }
  };
  input.click();
});

  // 发送按钮点击事件
document.querySelector('.send-btn').addEventListener('click', () => {
    if (messageInput.value.trim()) {  // 只有当消息不为空时送
    sendMessage();
    }
  });

  // 清空消息按钮点击事件
  document.querySelector('.clear-btn').addEventListener('click', () => {
    const chatBox = document.querySelector('.chat-wrapper');
    chatBox.innerHTML = '';
    lastMessageTime = 0;
  });

  // 初始化表情选择器
  initEmojiPicker();
  
  // 表情按钮点击事件
  document.querySelector('.emoji-btn').addEventListener('click', (e) => {
    e.stopPropagation();
    toggleEmojiPicker();
  });
  
  // 点击其他地方关闭表情选择器
  document.addEventListener('click', (e) => {
    const picker = document.getElementById('emojiPicker');
    if (!picker.contains(e.target) && !e.target.closest('.emoji-btn')) {
      picker.classList.add('hidden');
    }
  });
  
  // 图片按钮点击事件
  document.querySelector('.image-btn').addEventListener('click', () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      if (e.target.files.length > 0) {
        handleImageSelect(e.target.files[0]);
      }
    };
    input.click();
  });

  // 初始化@功能
  messageInput.addEventListener('input', (e) => {
    const pos = e.target.selectionStart;
    const value = e.target.value;
    
    // 检查是否正在输入@
    if (value[pos - 1] === '@') {
      mentionState = {
        active: true,
        startPos: pos,
        endPos: pos,
        filterText: ''
      };
      showMentionPicker();
    } else if (mentionState.active) {
      // 更���过滤文本
      mentionState.filterText = value.slice(mentionState.startPos, pos);
      mentionState.endPos = pos;
      updateMentionPicker();
    }
  });
  
  messageInput.addEventListener('keydown', (e) => {
    if (!mentionState.active) return;
    
    if (e.key === 'Escape') {
      closeMentionPicker();
      mentionState.active = false;
    } else if (e.key === 'Enter' && !e.shiftKey) {
      const selectedUser = document.querySelector('#mentionPicker .mention-item.selected');
      if (selectedUser) {
        e.preventDefault();
        insertMention(selectedUser.dataset.userId);
      }
    } else if (e.key === 'ArrowUp' || e.key === 'ArrowDown') {
      e.preventDefault();
      navigateMentionPicker(e.key === 'ArrowUp' ? -1 : 1);
    }
  });
  
  // 显示@用户选择器
  function showMentionPicker() {
    const input = document.getElementById('messageInput');
    const rect = input.getBoundingClientRect();
    const caretCoords = getCaretCoordinates(input, input.selectionStart);
    
    mentionPicker.style.left = `${rect.left + caretCoords.left}px`;
    mentionPicker.style.top = `${rect.top + caretCoords.top - mentionPicker.offsetHeight}px`;
    mentionPicker.classList.remove('hidden');
    
    updateMentionPicker();
  }
  
  // 更新@用户列表
  function updateMentionPicker() {
    const otherUsers = users.filter(u => !u.isMe);
    const filteredUsers = mentionState.filterText
      ? otherUsers.filter(u => 
          u.nickname.toLowerCase().includes(mentionState.filterText.toLowerCase()))
      : otherUsers;
    
    const list = mentionPicker.querySelector('div');
    list.innerHTML = filteredUsers.map((user, index) => `
      <div class="mention-item ${index === 0 ? 'selected' : ''}" data-user-id="${user.id}">
        <div class="flex items-center gap-2 p-2 rounded hover:bg-white/10 cursor-pointer">
          <img class="w-6 h-6 rounded" src="${user.avatar}" alt="${user.nickname}">
          <span class="text-sm text-white/90">${user.nickname}</span>
        </div>
      </div>
    `).join('');
    
    // 添加点击事件
    list.querySelectorAll('.mention-item').forEach(item => {
      item.addEventListener('click', () => {
        insertMention(item.dataset.userId);
      });
    });
  }
  
  // 插入@用户
  function insertMention(userId) {
    const input = document.getElementById('messageInput');
    const value = input.value;
    const mentionedUser = users.find(u => u.id === userId);
    
    if (mentionedUser) {
      // 使用特殊标记来表示@消息
      const mention = `@[${userId}:${mentionedUser.nickname}]`;
      
      // 在当前光标位置插入@消息
      const newValue = 
        value.slice(0, mentionState.startPos - 1) + 
        mention +
        value.slice(mentionState.endPos);
      
      input.value = newValue;
      
      // 设置光标位置到@消息后面
      const newCursorPos = mentionState.startPos - 1 + mention.length;
      input.selectionStart = input.selectionEnd = newCursorPos;
    }
    
    closeMentionPicker();
    // 确保完全重置mentionState状态
    mentionState.active = false;
    mentionState.startPos = 0;
    mentionState.endPos = 0;
    mentionState.filterText = '';
  }
  
  // 关闭@用户选择器
  function closeMentionPicker() {
    mentionPicker.classList.add('hidden');
    // 确保完全重置mentionState状态
    mentionState.active = false;
    mentionState.startPos = 0;
    mentionState.endPos = 0;
    mentionState.filterText = '';
  }
  
  // 导航@用户列表
  function navigateMentionPicker(direction) {
    const items = mentionPicker.querySelectorAll('.mention-item');
    const currentIndex = Array.from(items).findIndex(item => 
      item.classList.contains('selected')
    );
    
    items[currentIndex]?.classList.remove('selected');
    
    let newIndex = currentIndex + direction;
    if (newIndex < 0) newIndex = items.length - 1;
    if (newIndex >= items.length) newIndex = 0;
    
    items[newIndex]?.classList.add('selected');
  }
  
  // 点击其他地方关闭@用户选择器
  document.addEventListener('click', (e) => {
    if (!mentionPicker.contains(e.target) && e.target !== messageInput) {
      closeMentionPicker();
    }
  });

  // 点击其他地方关闭右键菜单
  document.addEventListener('click', (e) => {
    if (!e.target.closest('#contextMenu')) {
      hideContextMenu();
    }
  });
  
  // 滚动时关闭右键菜单
  document.querySelector('.chat-wrapper').addEventListener('scroll', () => {
    hideContextMenu();
  });
  
  // 窗口大小改变时关闭右键菜单
  window.addEventListener('resize', () => {
    hideContextMenu();
  });
  
  // 防止右键菜单超出视口
  const contextMenu = document.getElementById('contextMenu');
  document.addEventListener('contextmenu', (e) => {
    const x = e.pageX;
    const y = e.pageY;
    const menuWidth = contextMenu.offsetWidth;
    const menuHeight = contextMenu.offsetHeight;
    const windowWidth = window.innerWidth;
    const windowHeight = window.innerHeight;
    
    if (x + menuWidth > windowWidth) {
      contextMenu.style.left = `${windowWidth - menuWidth}px`;
    }
    
    if (y + menuHeight > windowHeight) {
      contextMenu.style.top = `${windowHeight - menuHeight}px`;
    }
  });

  // 添加全���粘贴事件监听
  document.addEventListener('paste', (e) => {
    // 如果当前焦点已经在输入框，不需要处理
    if (document.activeElement === messageInput) {
      return;
    }
    
    // 获取粘贴的文本内容
    const pastedText = e.clipboardData.getData('text/plain');
    if (!pastedText) {
      return;
    }
    
    // 阻止默认粘贴行为
    e.preventDefault();
    
    // 聚焦输入框
    messageInput.focus();
    
    // 在当前光标位置插入文本
    const start = messageInput.selectionStart;
    const end = messageInput.selectionEnd;
    const text = messageInput.value;
    
    messageInput.value = text.substring(0, start) + pastedText + text.substring(end);
    
    // 设置光标位置到插入文本的末尾
    const newCursorPos = start + pastedText.length;
    messageInput.selectionStart = messageInput.selectionEnd = newCursorPos;
  });

  // 监听输入框的按键事件，处理@消息的删除
  messageInput.addEventListener('keydown', (e) => {
    if (e.key === 'Backspace') {
      const value = messageInput.value;
      const cursorPos = messageInput.selectionStart;
      
      // 检查光标前面是否有@消息标记
      const beforeCursor = value.substring(0, cursorPos);
      const mentionMatch = beforeCursor.match(/@\[[^:]+:[^\]]+\]$/);
      
      if (mentionMatch) {
        e.preventDefault();
        // 删除整个@消息标记
        const newValue = value.substring(0, cursorPos - mentionMatch[0].length) + 
                        value.substring(cursorPos);
        messageInput.value = newValue;
        messageInput.selectionStart = messageInput.selectionEnd = 
          cursorPos - mentionMatch[0].length;
      }
    }
  });
  
  // 发送消息时处理@消息
  function sendMessage(msg) {
    const message = msg ?? messageInput.value;
    if (!message.trim()) return;
    
    // 将特殊标记转换为服务器格式
    const processedMessage = message.replace(
      /@\[([^:]+):([^\]]+)\]/g,
      (_, userId) => `@[${userId}]`
    );
    
    addChatItem(me, processedMessage);
    
    users.forEach(u => {
      if (!u.isMe) {
        u.sendMessage(processedMessage);
      }
    });
    
    messageInput.value = '';
  }
});

// 获取输入框光标位置的工具函数
function getCaretCoordinates(element, position) {
  const div = document.createElement('div');
  const style = getComputedStyle(element);
  const properties = [
    'direction', 'boxSizing', 'width', 'height', 'overflowX', 'overflowY',
    'borderTopWidth', 'borderRightWidth', 'borderBottomWidth', 'borderLeftWidth',
    'paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft',
    'fontStyle', 'fontVariant', 'fontWeight', 'fontStretch', 'fontSize',
    'fontSizeAdjust', 'lineHeight', 'fontFamily', 'textAlign', 'textTransform',
    'textIndent', 'textDecoration', 'letterSpacing', 'wordSpacing'
  ];
  
  div.style.position = 'absolute';
  div.style.visibility = 'hidden';
  div.style.whiteSpace = 'pre-wrap';
  
  properties.forEach(prop => {
    div.style[prop] = style[prop];
  });
  
  div.textContent = element.value.substring(0, position);
  const span = document.createElement('span');
  span.textContent = element.value.substring(position) || '.';
  div.appendChild(span);
  
  document.body.appendChild(div);
  const coordinates = {
    top: span.offsetTop + parseInt(style.borderTopWidth) + parseInt(style.paddingTop),
    left: span.offsetLeft + parseInt(style.borderLeftWidth) + parseInt(style.paddingLeft)
  };
  document.body.removeChild(div);
  
  return coordinates;
}

// 修改文件处理相关代码
function handleFileSelect(file) {
  if (file.type.startsWith('image/')) {
    handleImageSelect(file);
  } else {
    sendFile(file);
  }
}