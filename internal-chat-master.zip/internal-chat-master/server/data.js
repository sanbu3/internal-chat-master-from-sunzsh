const adjectives = [
  '快乐的', '机智的', '可爱的', '温柔的', '调皮的', '聪明的', '活泼的', '开朗的',
  '呆萌的', '懒懒的', '优雅的', '神秘的', '萌萌的', '酷酷的', '文艺的', '傲娇的',
  '忧郁的', '沉默的', '可靠的', '认真的', '搞笑的', '贪吃的', '迷糊的', '帅气的'
];
const nouns = [
  '小猫', '小狗', '小兔', '小鸟', '小熊', '小鹿', '小象', '小狐狸',
  '企鹅', '浣熊', '考拉', '海豚', '松鼠', '小羊', '小猪', '小鸭',
  '树懒', '仓鼠', '小鹦鹉', '小刺猬', '小熊猫', '小袋鼠', '小河马', '小长颈鹿'
];

function generateNickname() {
  const adj = adjectives[Math.floor(Math.random() * adjectives.length)];
  const noun = nouns[Math.floor(Math.random() * nouns.length)];
  return adj + noun;
}

const data = {
  
}

/*
  A类地址：10.0.0.0–10.255.255.255
  B类地址：172.16.0.0–172.31.255.255 
  C类地址：192.168.0.0–192.168.255.255
*/
function internalNet(ip) {
  if (ip.startsWith('10.')) {
    return true;
  }
  if (ip.startsWith('172.')) {
    const second = parseInt(ip.split('.')[1]);
    if (second >= 16 && second <= 31) {
      return true;
    }
  }
  if (ip.startsWith('192.168.')) {
    return true;
  }
  return false;
}

function getKey(ip) {
  const isInternalNet = internalNet(ip);
  return isInternalNet ? 'internal' : ip;
}

function registerUser(ip, socket) {
  const key = getKey(ip);
  if (!data[key]) {
    data[key] = [];
  }
  const room = data[key];
  
  // 生成唯一昵称
  let nickname;
  do {
    nickname = generateNickname();
  } while (room.find(user => user.nickname === nickname));
  
  room.push({
    id: nickname, // 使用生成的昵称作为ID
    nickname,
    socket,
    joinTime: Date.now(),
    avatar: `https://api.dicebear.com/7.x/bottts/svg?seed=${nickname}`,
    targets: {}
  });
  return nickname;
}

function unregisterUser(ip, id) {
  const key = getKey(ip);
  const room = data[key]
  if (room) {
    const index = room.findIndex(user => user.id === id)
    if (index !== -1) {
      return room.splice(index, 1)
    }
  }
}

function getUserList(ip) {
  const key = getKey(ip);
  const room = data[key]
  // 去掉socket属性
  return room ?? []
}

function getUser(ip, uid) {
  const key = getKey(ip);
  const room = data[key]
  return room.find(user => user.id === uid)
}

module.exports = { registerUser, unregisterUser, getUserList, getUser }